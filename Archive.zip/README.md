Webstore

   Work Done
   
      - Created navigation bar that allows you to completely naviage through web app
      
      - Added a home page to show what we will be selling on the web app
      
      - Created a sign in page that DOES NOT DO ANYTHING
      
      - Created a products page to show case the products, and their prices
      
      - Orignally created the website with inspiration to use an amazon api but instead modified original idea to just sell "cool beers"
      
      - Renamed app to Ghetto Amazon to Ghetto Beer

   




